<?php


namespace Shopier\Enums;


class Currency
{
    const TL = 0;
    const USD = 1;
    const EUR = 2;
}