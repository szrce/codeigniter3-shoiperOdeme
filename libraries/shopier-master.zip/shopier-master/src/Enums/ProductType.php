<?php


namespace Shopier\Enums;


class ProductType
{
    const REAL = 0;
    const DOWNLOADABLE_VIRTUAL = 1;
    const DEFAULT_TYPE = 2;
}