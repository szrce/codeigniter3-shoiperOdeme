<?php


namespace Shopier\Exceptions;


use Exception;

class RequiredParameterException extends Exception
{

}