<?php


namespace Shopier\Exceptions;


use Exception;

class NotRendererClassException extends Exception
{

}