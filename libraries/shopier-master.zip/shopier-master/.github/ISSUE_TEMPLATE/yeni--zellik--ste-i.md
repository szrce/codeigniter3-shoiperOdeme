---
name: Yeni Özellik İsteği
about: Bu proje için bir fikir öner
title: ''
labels: ''
assignees: ''

---

** Özellik isteğiniz bir sorunla mı ilgili? Lütfen tanımla.**
Sorunun ne olduğu konusunda net ve kısa bir açıklama. 

** İstediğiniz çözümü açıklayın **
Ne olmasını istediğinin net ve öz açıklaması.

** Düşündüğünüz alternatifleri tanımlayın **
Düşündüğünüz alternatif çözümlerin veya özelliklerin net ve kısa bir açıklaması.

** Ek bağlam **
Buradaki özellik isteği hakkında başka bir bağlam veya ekran görüntüsü ekleyin.
